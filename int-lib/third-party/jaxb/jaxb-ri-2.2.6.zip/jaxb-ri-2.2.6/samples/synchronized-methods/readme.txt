** UNSUPPORTED ** THIS FUNCTIONALITY MAY BE REMOVED IN FUTURE.

This example shows how to use the JAXB RI synchronized method extension.

This extension changes the generated code in the following way:

  - Each generated method will have the "synchronized" keyword.
  
To enable this extension, you have to specify the "-Xsync-methods" switch
on the command line.
